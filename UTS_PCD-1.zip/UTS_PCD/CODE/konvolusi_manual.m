clc; clear; close all;

f = imread('Picture1.jpg');
f = double(f);

[x, y] = meshgrid(-3:3, -3:3);
sigma = 1.0;
mask = exp(-(x.^2 + y.^2) / (2*sigma^2));
mask = mask / sum(mask(:));

[M, N, C] = size(f);
[m, n] = size(mask);
pad_row = floor(m/2);
pad_col = floor(n/2);

f_pad = padarray(f, [pad_row pad_col], 0, 'both');
g_manual = zeros(M, N, C);

for c = 1:C
    for x = 1:M
        for y = 1:N
            region = f_pad(x:x+m-1, y:y+n-1, c);
            g_manual(x,y,c) = sum(sum(region .* mask));
        end
    end
end

if C == 3
    g_builtin(:,:,1) = conv2(f(:,:,1), mask, 'same');
    g_builtin(:,:,2) = conv2(f(:,:,2), mask, 'same');
    g_builtin(:,:,3) = conv2(f(:,:,3), mask, 'same');
else
    g_builtin = conv2(f, mask, 'same');
end

figure;
subplot(1,3,1); imshow(uint8(f)); title('Citra Asli');
subplot(1,3,2); imshow(uint8(g_manual)); title('Konvolusi Manual (Gaussian 7x7)');
subplot(1,3,3); imshow(uint8(g_builtin)); title('Conv2 MATLAB (Gaussian 7x7)');

error_value = sum(sum(abs(double(g_manual(:)) - double(g_builtin(:)))));
fprintf('Perbedaan nilai antara manual dan conv2: %.4f\n', error_value);
