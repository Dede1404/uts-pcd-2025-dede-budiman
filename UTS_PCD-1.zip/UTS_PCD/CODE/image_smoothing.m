clc; clear; close all;

f = imread('gambar1.jpg');
f = double(f);

% Modifikasi Efek
[M, N, ~] = size(f);
D0 = 10;
n = 5;

[u, v] = meshgrid(0:N-1, 0:M-1);
u = u - floor(N/2);
v = v - floor(M/2);
D = sqrt(u.^2 + v.^2);

% Filter di domain frekuensi
H_ILPF = double(D <= D0);
H_GLPF = exp(-(D.^2)./(2*(D0^2)));
H_BLPF = 1 ./ (1 + (D./D0).^(2*n));

% Inisialisasi hasil untuk tiap channel
g1 = zeros(M, N, 3);
g2 = zeros(M, N, 3);
g3 = zeros(M, N, 3);

% Terapkan filter pada masing-masing channel (R, G, B)
for c = 1:3
    Fc = fft2(f(:,:,c));
    Fshift = fftshift(Fc);

    G1 = Fshift .* H_ILPF;
    G2 = Fshift .* H_GLPF;
    G3 = Fshift .* H_BLPF;

    g1(:,:,c) = real(ifft2(ifftshift(G1)));
    g2(:,:,c) = real(ifft2(ifftshift(G2)));
    g3(:,:,c) = real(ifft2(ifftshift(G3)));
end

% Tampilkan hasil
figure;
subplot(2,3,1); imshow(uint8(f)); title('Asli');
subplot(2,3,2); imshow(log(1+abs(fftshift(fft2(rgb2gray(uint8(f)))))),[]); title('Spektrum');
subplot(2,3,4); imshow(uint8(g1)); title('ILPF');
subplot(2,3,5); imshow(uint8(g2)); title('GLPF');
subplot(2,3,6); imshow(uint8(g3)); title('BLPF');
