clc; clear; close all;

f = imread('pic1.jpg');
f = im2double(f);
isColor = (size(f,3) == 3);

D0 = 40;
n = 2;
a = 0.3;
b = 2.0;

[M, N, ~] = size(f);
[u,v] = meshgrid(0:N-1,0:M-1);
u = u - floor(N/2);
v = v - floor(M/2);
D = sqrt(u.^2 + v.^2);

H_BLPF = 1 ./ (1 + (D./D0).^(2*n));
H_BHPF = 1 - H_BLPF;
H_HFE = a + b * H_BHPF;

if isColor
    F_R = fftshift(fft2(f(:,:,1)));
    F_G = fftshift(fft2(f(:,:,2)));
    F_B = fftshift(fft2(f(:,:,3)));

    G_R = H_HFE .* F_R;
    G_G = H_HFE .* F_G;
    G_B = H_HFE .* F_B;

    g(:,:,1) = real(ifft2(ifftshift(G_R)));
    g(:,:,2) = real(ifft2(ifftshift(G_G)));
    g(:,:,3) = real(ifft2(ifftshift(G_B)));
else
    F = fftshift(fft2(f));
    G = H_HFE .* F;
    g = real(ifft2(ifftshift(G)));
end

g = mat2gray(g);

figure;
subplot(1,2,1); imshow(f); title('Asli');
subplot(1,2,2); imshow(g); title('Hasil High Frequency');
