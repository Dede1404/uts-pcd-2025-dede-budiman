clc; clear; close all;

f = imread('gambar2.jpg');
f = im2double(f);
sp_prob = 0.05;

if size(f,3)==1
    f_sp = imnoise(f,'salt & pepper',sp_prob);
    f_gauss = imnoise(f,'gaussian',0,0.01);
else
    f_sp = zeros(size(f));
    f_gauss = zeros(size(f));
    for c = 1:3
        f_sp(:,:,c) = imnoise(f(:,:,c),'salt & pepper',sp_prob);
        f_gauss(:,:,c) = imnoise(f(:,:,c),'gaussian',0,0.01);
    end
end

w = 3;
pad = floor(w/2);

if size(f,3)==1
    fpad = padarray(f_sp,[pad pad],0,'both');
    [M,N] = size(f_sp);
    out_min = zeros(M,N);
    out_max = zeros(M,N);
    out_median = zeros(M,N);
    out_arith = zeros(M,N);
    out_geom = zeros(M,N);
    out_harm = zeros(M,N);
    out_contra = zeros(M,N);
    out_mid = zeros(M,N);
    out_trim = zeros(M,N);
    Q = 1.5;
    d = 2;
    for i=1:M
        for j=1:N
            region = fpad(i:i+2*pad,j:j+2*pad);
            vec = region(:);
            out_min(i,j) = min(vec);
            out_max(i,j) = max(vec);
            out_median(i,j) = median(vec);
            out_arith(i,j) = mean(vec);
            out_geom(i,j) = exp(mean(log(max(vec,1e-6))));
            out_harm(i,j) = numel(vec) / sum(1./max(vec,1e-6));
            out_contra(i,j) = sum(vec.^(Q+1)) / sum(vec.^Q);
            out_mid(i,j) = (max(vec)+min(vec))/2;
            s = sort(vec);
            s2 = s(d+1:end-d);
            out_trim(i,j) = mean(s2);
        end
    end
else
    out_min = zeros(size(f_sp));
    out_max = zeros(size(f_sp));
    out_median = zeros(size(f_sp));
    out_arith = zeros(size(f_sp));
    out_geom = zeros(size(f_sp));
    out_harm = zeros(size(f_sp));
    out_contra = zeros(size(f_sp));
    out_mid = zeros(size(f_sp));
    out_trim = zeros(size(f_sp));
    Q = 1.5;
    d = 2;
    for c = 1:3
        fpad = padarray(f_sp(:,:,c),[pad pad],0,'both');
        [M,N] = size(f_sp(:,:,c));
        for i=1:M
            for j=1:N
                region = fpad(i:i+2*pad,j:j+2*pad);
                vec = region(:);
                out_min(i,j,c) = min(vec);
                out_max(i,j,c) = max(vec);
                out_median(i,j,c) = median(vec);
                out_arith(i,j,c) = mean(vec);
                out_geom(i,j,c) = exp(mean(log(max(vec,1e-6))));
                out_harm(i,j,c) = numel(vec) / sum(1./max(vec,1e-6));
                out_contra(i,j,c) = sum(vec.^(Q+1)) / sum(vec.^Q);
                out_mid(i,j,c) = (max(vec)+min(vec))/2;
                s = sort(vec);
                s2 = s(d+1:end-d);
                out_trim(i,j,c) = mean(s2);
            end
        end
    end
end

figure;
subplot(3,4,1); imshow(f); title('Asli');
subplot(3,4,2); imshow(f_sp); title('Salt & Pepper');
subplot(3,4,3); imshow(out_min); title('Min');
subplot(3,4,4); imshow(out_max); title('Max');
subplot(3,4,5); imshow(out_median); title('Median');
subplot(3,4,6); imshow(out_arith); title('Arithmetic Mean');
subplot(3,4,7); imshow(out_geom); title('Geometric Mean');
subplot(3,4,8); imshow(out_harm); title('Harmonic Mean');
subplot(3,4,9); imshow(out_contra); title('Contraharmonic');
subplot(3,4,10); imshow(out_mid); title('Midpoint');
subplot(3,4,11); imshow(out_trim); title('Alpha-trimmed');
subplot(3,4,12); imshow(f_gauss); title('Gaussian Noise');
