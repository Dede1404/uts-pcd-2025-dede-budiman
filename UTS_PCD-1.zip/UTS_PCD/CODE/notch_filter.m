clc; clear; close all;

f = imread('enam7.jpg');
f = im2double(f);
if size(f,3)==3
    f_gray = rgb2gray(f);
else
    f_gray = f;
end

F = fftshift(fft2(f_gray));
[M,N] = size(f_gray);
[U,V] = meshgrid(-floor(N/2):ceil(N/2)-1, -floor(M/2):ceil(M/2)-1);

% ==== Parameter Notch Reject Filter ====
D0 = 10;       % cutoff (radius pengaruh notch)
n  = 2;        % order filter (Butterworth)
centers = [    % posisi puncak noise hasil observasi spektrum
     36  28;
    -36 -28;
     36 -28;
    -36  28
];

% ==== Bentuk Notch Reject Filter (Butterworth) ====
H = ones(M,N);
for k = 1:size(centers,1)
    uc = centers(k,1);
    vc = centers(k,2);
    Dk  = sqrt((U-uc).^2 + (V-vc).^2);
    Dk_ = sqrt((U+uc).^2 + (V+vc).^2);
    H = H .* ( 1 ./ (1 + (D0.^2 ./ (Dk.*Dk_)).^n) );
end

% ==== Aplikasikan filter di ranah frekuensi ====
G = ifft2(ifftshift(F .* H));
out = real(G);
out = mat2gray(out);

% ==== Tampilkan hasil ====
figure;
subplot(1,3,1); imshow(f_gray,[]); title('Noisy (Bergelombang)');
subplot(1,3,2); imshow(log(1+abs(F)),[]); title('Spektrum Fourier');
subplot(1,3,3); imshow(out,[]); title('Setelah Notch Reject Filter');
figure; imshow(H,[]); title('Mask Filter H');
