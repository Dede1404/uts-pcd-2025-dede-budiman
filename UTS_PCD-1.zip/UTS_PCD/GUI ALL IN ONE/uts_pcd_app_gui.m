function uts_pcd_app_gui
clc; clear; close all;
% main figure
hFig = figure('Name','UTS PCD - All-in-One','NumberTitle','off','MenuBar','none','ToolBar','none','Position',[100 80 1200 760]);
% axes
axW = 520; axH = 460;
axPad = 40;
hAxOrig = axes('Parent',hFig,'Units','pixels','Position',[axPad 250 axW axH]);
hAxRes  = axes('Parent',hFig,'Units','pixels','Position',[axPad+axW+40 250 axW axH]);
uicontrol('Style','text','Position',[axPad 720 200 22],'String','Original Image','FontWeight','bold','BackgroundColor',get(hFig,'Color'));
uicontrol('Style','text','Position',[axPad+axW+40 720 200 22],'String','Result Image','FontWeight','bold','BackgroundColor',get(hFig,'Color'));
% status
hStatus = uicontrol('Style','text','Position',[40 200 1120 36],'String','Status: Ready','HorizontalAlignment','left','BackgroundColor',get(hFig,'Color'));
% bottom button panel coordinates
btnW = 160; btnH = 34; gap = 12;
bottomY = 40;
colX = [40, 220, 400, 580, 760, 940]; % columns for buttons
% buttons (arranged in rows)
uicontrol('Style','pushbutton','String','Load Image','Position',[colX(1) bottomY btnW btnH],'Callback',@cbLoad);
uicontrol('Style','pushbutton','String','Reset','Position',[colX(2) bottomY btnW btnH],'Callback',@cbReset);
uicontrol('Style','pushbutton','String','Save Result','Position',[colX(3) bottomY btnW btnH],'Callback',@cbSave);
uicontrol('Style','pushbutton','String','Exit','Position',[colX(6) bottomY btnW btnH],'Callback',@cbExit);

uicontrol('Style','pushbutton','String','Konvolusi Manual','Position',[colX(1) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbConvManual);
uicontrol('Style','pushbutton','String','Smoothing Spasial','Position',[colX(2) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbSmoothSpatial);
uicontrol('Style','pushbutton','String','Smoothing Frekuensi','Position',[colX(3) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbSmoothFreq);
uicontrol('Style','pushbutton','String','Highpass Frekuensi','Position',[colX(4) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbHighpass);
uicontrol('Style','pushbutton','String','Brighten (HFE)','Position',[colX(5) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbBrighten);
uicontrol('Style','pushbutton','String','Add Noise','Position',[colX(6) bottomY+ (btnH+gap) btnW btnH],'Callback',@cbAddNoise);

uicontrol('Style','pushbutton','String','Noise Filters','Position',[colX(1) bottomY+2*(btnH+gap) btnW btnH],'Callback',@cbNoiseFilters);
uicontrol('Style','pushbutton','String','Notch Filter','Position',[colX(2) bottomY+2*(btnH+gap) btnW btnH],'Callback',@cbNotch);
uicontrol('Style','pushbutton','String','Motion & Wiener','Position',[colX(3) bottomY+2*(btnH+gap) btnW btnH],'Callback',@cbWiener);
uicontrol('Style','pushbutton','String','Show Original','Position',[colX(4) bottomY+2*(btnH+gap) btnW btnH],'Callback',@cbShowOrig);

% data
img = []; imgOrig = []; imgRes = [];

setStatus('Ready');

    function setStatus(txt)
        set(hStatus,'String',['Status: ' txt]);
        drawnow;
    end

    function cbLoad(~,~)
        [f,p] = uigetfile({'*.png;*.jpg;*.jpeg;*.tif;*.bmp','Image Files'});
        if isequal(f,0), setStatus('Load cancelled'); return; end
        try
            im = imread(fullfile(p,f));
        catch
            setStatus('Failed to read image'); return;
        end
        img = im;
        imgOrig = img;
        imgRes = img;
        axes(hAxOrig); imshow(img); title('Original');
        axes(hAxRes); imshow(imgRes); title('Result');
        setStatus(['Loaded: ' f]);
    end

    function cbReset(~,~)
        if isempty(imgOrig), setStatus('No image loaded'); return; end
        img = imgOrig; imgRes = imgOrig;
        axes(hAxRes); imshow(imgRes); title('Result');
        setStatus('Reset to original image');
    end

    function cbSave(~,~)
        if isempty(imgRes), setStatus('No result to save'); return; end
        [f,p] = uiputfile({'*.png','PNG';'*.jpg','JPG';'*.tif','TIF'});
        if isequal(f,0), setStatus('Save cancelled'); return; end
        try
            imwrite(imgRes,fullfile(p,f));
            setStatus(['Saved: ' fullfile(p,f)]);
        catch
            setStatus('Save failed');
        end
    end

    function cbExit(~,~)
        close(hFig);
    end

    function cbShowOrig(~,~)
        if isempty(imgOrig), setStatus('No image loaded'); return; end
        axes(hAxRes); imshow(imgOrig); title('Original (preview)');
        setStatus('Displayed original image on Result panel');
    end

    function cbConvManual(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'Enter mask as MATLAB matrix (example: [1 1 1;1 1 1;1 1 1]/9 )'};
        def = {'[1 1 1;1 1 1;1 1 1]/9'};
        answ = inputdlg(prompt,'Konvolusi Manual',1,def);
        if isempty(answ), setStatus('Operation cancelled'); return; end
        mask = str2num(answ{1}); %#ok<ST2NM>
        if isempty(mask), setStatus('Invalid mask'); return; end
        setStatus('Running manual convolution and comparison...');
        % manual conv (per-channel)
        manualOut = manual_conv_image(img,mask);
        % builtin conv2 comparison
        builtinOut = builtin_conv_image(img,mask);
        % show comparison figure
        fh = figure('Name','Konvolusi: Manual vs Built-in','NumberTitle','off','Position',[200 150 1000 420]);
        if ndims(img)==3
            subplot(1,3,1); imshow(img); title('Original');
            subplot(1,3,2); imshow(manualOut); title('Manual Convolution');
            subplot(1,3,3); imshow(builtinOut); title('Built-in conv2');
        else
            subplot(1,3,1); imshow(img); title('Original');
            subplot(1,3,2); imshow(manualOut); title('Manual Convolution');
            subplot(1,3,3); imshow(builtinOut); title('Built-in conv2');
        end
        % set manual result to result panel
        imgRes = manualOut;
        axes(hAxRes); imshow(imgRes); title('Konvolusi Manual (Result)');
        setStatus('Konvolusi manual and comparison done');
    end

    function cbSmoothSpatial(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'Filter type: mean or gaussian','Kernel size (odd integer)'};
        def = {'mean','3'};
        answ = inputdlg(prompt,'Smoothing Spasial',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        ftype = lower(strtrim(answ{1})); k = str2double(answ{2});
        if isnan(k)||mod(k,2)==0, setStatus('Invalid kernel size'); return; end
        setStatus('Running spatial smoothing...');
        if strcmp(ftype,'mean')
            kernel = ones(k,k)/ (k*k);
        else
            kernel = fspecial('gaussian',k,0.5*(k-1)/6);
        end
        out = manual_conv_image(img,kernel);
        imgRes = out;
        axes(hAxRes); imshow(imgRes); title(['Smoothing Spasial: ' ftype]);
        setStatus('Smoothing spatial done');
    end

    function cbSmoothFreq(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'Filter type: ILPF / GLPF / BLPF','D0 (cutoff, e.g.30)','n (Butterworth order e.g.2)'};
        def = {'GLPF','30','2'};
        answ = inputdlg(prompt,'Smoothing Frekuensi',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        ftype = upper(strtrim(answ{1})); D0 = str2double(answ{2}); n = str2double(answ{3});
        setStatus('Running frequency smoothing...');
        I = double(img);
        [M,N,~] = size(I);
        [u,v] = meshgrid(0:N-1,0:M-1);
        u = u - floor(N/2); v = v - floor(M/2);
        D = sqrt(u.^2 + v.^2);
        if strcmp(ftype,'ILPF')
            H = double(D<=D0);
        elseif strcmp(ftype,'GLPF')
            H = exp(-(D.^2)./(2*(D0^2)));
        else
            H = 1./(1 + (D./D0).^(2*n));
        end
        if ndims(I)==3
            out = zeros(size(I),'double');
            for c=1:3
                F = fftshift(fft2(double(I(:,:,c))));
                G = ifft2(ifftshift(F .* H));
                out(:,:,c) = real(G);
            end
            imgRes = cast(uint8(out),class(img));
        else
            F = fftshift(fft2(I));
            G = ifft2(ifftshift(F .* H));
            imgRes = cast(uint8(real(G)),class(img));
        end
        axes(hAxRes); imshow(imgRes); title(['Smoothing Freq: ' ftype]);
        setStatus('Smoothing frequency done');
    end

    function cbHighpass(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'Filter type: IHPF / GHPF / BHPF','D0 (e.g.30)','n (Butterworth order e.g.2)'};
        def = {'GHPF','30','2'};
        answ = inputdlg(prompt,'Highpass Frequency',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        ftype = upper(strtrim(answ{1})); D0 = str2double(answ{2}); n = str2double(answ{3});
        setStatus('Running highpass...');
        I = double(img);
        [M,N,~] = size(I);
        [u,v] = meshgrid(0:N-1,0:M-1);
        u = u - floor(N/2); v = v - floor(M/2);
        D = sqrt(u.^2 + v.^2);
        Hlp = 1./(1 + (D./D0).^(2*n));
        if strcmp(ftype,'IHPF')
            H = double(D > D0);
        elseif strcmp(ftype,'GHPF')
            H = 1 - exp(-(D.^2)./(2*(D0^2)));
        else
            H = 1 - Hlp;
        end
        if ndims(I)==3
            out = zeros(size(I),'double');
            for c=1:3
                F = fftshift(fft2(double(I(:,:,c))));
                G = ifft2(ifftshift(F .* H));
                out(:,:,c) = real(G);
            end
            imgRes = cast(uint8(abs(out)),class(img));
        else
            F = fftshift(fft2(I));
            G = ifft2(ifftshift(F .* H));
            imgRes = cast(uint8(abs(real(G))),class(img));
        end
        axes(hAxRes); imshow(imgRes); title(['Highpass: ' ftype]);
        setStatus('Highpass done');
    end

    function cbBrighten(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'a (base, e.g.0.5)','b (emphasis, e.g.1.5)','D0 (e.g.40)','n (e.g.2)'};
        def = {'0.5','1.5','40','2'};
        answ = inputdlg(prompt,'High-Frequency Emphasis',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        a = str2double(answ{1}); b = str2double(answ{2}); D0 = str2double(answ{3}); n = str2double(answ{4});
        setStatus('Running HFE brighten...');
        I = double(img);
        [M,N,~] = size(I);
        [u,v] = meshgrid(0:N-1,0:M-1);
        u = u - floor(N/2); v = v - floor(M/2);
        D = sqrt(u.^2 + v.^2);
        Hbp = 1 ./ (1 + (D./D0).^(2*n));
        Hhp = 1 - Hbp;
        Hhfe = a + b * Hhp;
        if ndims(I)==3
            out = zeros(size(I),'double');
            for c=1:3
                F = fftshift(fft2(double(I(:,:,c))));
                G = ifft2(ifftshift(F .* Hhfe));
                out(:,:,c) = real(G);
            end
            imgRes = cast(uint8(out),class(img));
        else
            F = fftshift(fft2(I));
            G = ifft2(ifftshift(F .* Hhfe));
            imgRes = cast(uint8(real(G)),class(img));
        end
        axes(hAxRes); imshow(imgRes); title('HFE Brighten');
        setStatus('HFE done');
    end

    function cbAddNoise(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'S&P prob (0-1)','Gaussian variance (e.g.0.01)'};
        def = {'0.05','0.01'};
        answ = inputdlg(prompt,'Add Noise',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        sp = str2double(answ{1}); gv = str2double(answ{2});
        setStatus('Adding noise...');
        I = img;
        if ndims(I)==3
            out = zeros(size(I),'like',I);
            for c=1:3
                tmp = imnoise(I(:,:,c),'salt & pepper',sp);
                tmp = imnoise(tmp,'gaussian',0,gv);
                out(:,:,c) = tmp;
            end
        else
            out = imnoise(I,'salt & pepper',sp);
            out = imnoise(out,'gaussian',0,gv);
        end
        imgRes = out;
        axes(hAxRes); imshow(imgRes); title('Noisy Image');
        setStatus('Noise added');
    end

    function cbNoiseFilters(~,~)
        if isempty(imgRes), setStatus('Noisy image needed: use Add Noise first'); return; end
        setStatus('Running noise filters (manual) ...');
        I = double(imgRes);
        w = 3;
        if ndims(I)==3
            % process each channel
            outMin=zeros(size(I)); outMax=zeros(size(I)); outMed=zeros(size(I));
            outArith=zeros(size(I)); outGeom=zeros(size(I)); outHarm=zeros(size(I));
            outContra=zeros(size(I)); outMid=zeros(size(I)); outTrim=zeros(size(I));
            for c=1:3
                ch = local_noise_filters(I(:,:,c),w);
                outMin(:,:,c) = ch(:,:,1);
                outMax(:,:,c) = ch(:,:,2);
                outMed(:,:,c) = ch(:,:,3);
                outArith(:,:,c)= ch(:,:,4);
                outGeom(:,:,c) = ch(:,:,5);
                outHarm(:,:,c) = ch(:,:,6);
                outContra(:,:,c)= ch(:,:,7);
                outMid(:,:,c) = ch(:,:,8);
                outTrim(:,:,c)= ch(:,:,9);
            end
            figure('Name','Noise Filters Results');
            subplot(3,3,1); imshow(uint8(img)); title('Asli');
            subplot(3,3,2); imshow(uint8(imgRes)); title('Noisy');
            subplot(3,3,3); imshow(uint8(outMin)); title('Min');
            subplot(3,3,4); imshow(uint8(outMax)); title('Max');
            subplot(3,3,5); imshow(uint8(outMed)); title('Median');
            subplot(3,3,6); imshow(uint8(outArith)); title('Arithmetic');
            subplot(3,3,7); imshow(uint8(outGeom)); title('Geometric');
            subplot(3,3,8); imshow(uint8(outHarm)); title('Harmonic');
            subplot(3,3,9); imshow(uint8(outContra)); title('Contraharmonic');
            imgRes = uint8(outMed);
        else
            out = local_noise_filters(I,w);
            figure('Name','Noise Filters Results');
            subplot(3,3,1); imshow(uint8(img)); title('Asli');
            subplot(3,3,2); imshow(uint8(imgRes)); title('Noisy');
            subplot(3,3,3); imshow(uint8(out(:,:,1))); title('Min');
            subplot(3,3,4); imshow(uint8(out(:,:,2))); title('Max');
            subplot(3,3,5); imshow(uint8(out(:,:,3))); title('Median');
            subplot(3,3,6); imshow(uint8(out(:,:,4))); title('Arithmetic');
            subplot(3,3,7); imshow(uint8(out(:,:,5))); title('Geometric');
            subplot(3,3,8); imshow(uint8(out(:,:,6))); title('Harmonic');
            subplot(3,3,9); imshow(uint8(out(:,:,7))); title('Contraharmonic');
            imgRes = uint8(out(:,:,3));
        end
        axes(hAxRes); imshow(imgRes); title('Noise Filters - median');
        setStatus('Noise filtering done');
    end

    function R = local_noise_filters(I,w)
        pad = floor(w/2);
        Ip = padarray(I,[pad pad],0,'both');
        [M,N] = size(I);
        out_min=zeros(M,N); out_max=zeros(M,N); out_med=zeros(M,N);
        out_arith=zeros(M,N); out_geom=zeros(M,N); out_harm=zeros(M,N);
        out_contra=zeros(M,N); out_mid=zeros(M,N); out_trim=zeros(M,N);
        Q = 1.5; d = 2;
        for i=1:M
            for j=1:N
                block = Ip(i:i+2*pad,j:j+2*pad);
                v = block(:);
                out_min(i,j) = min(v);
                out_max(i,j) = max(v);
                out_med(i,j) = median(v);
                out_arith(i,j)= mean(v);
                out_geom(i,j) = exp(mean(log(max(v,1e-6))));
                out_harm(i,j) = numel(v)/sum(1./max(v,1e-6));
                out_contra(i,j)= sum(v.^(Q+1))/sum(v.^Q);
                out_mid(i,j) = (max(v)+min(v))/2;
                s = sort(v);
                s2 = s(d+1:end-d);
                if isempty(s2), out_trim(i,j)=mean(s); else out_trim(i,j)=mean(s2); end
            end
        end
        R = zeros(M,N,9);
        R(:,:,1)=out_min; R(:,:,2)=out_max; R(:,:,3)=out_med; R(:,:,4)=out_arith;
        R(:,:,5)=out_geom; R(:,:,6)=out_harm; R(:,:,7)=out_contra; R(:,:,8)=out_mid; R(:,:,9)=out_trim;
    end

    function cbNotch(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'Centers list (format: x1,y1;x2,y2)','Radius (e.g.6)'};
        def = {'30,40;-30,-40','6'};
        answ = inputdlg(prompt,'Notch Filter',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        centersStr = answ{1}; r = str2double(answ{2});
        C = strsplit(centersStr,';');
        centers = [];
        for k=1:numel(C)
            xy = str2num(C{k}); %#ok<ST2NM>
            if numel(xy)==2, centers = [centers; xy]; end
        end
        setStatus('Running notch filter...');
        I = double(img);
        [M,N,~] = size(I);
        [u,v] = meshgrid(1:N,1:M);
        Htot = ones(M,N);
        for k=1:size(centers,1)
            u0 = centers(k,1) + floor(N/2);
            v0 = centers(k,2) + floor(M/2);
            mask = ((u-u0).^2 + (v-v0).^2) <= r^2;
            Htot(mask) = 0;
        end
        if ndims(I)==3
            out = zeros(size(I),'double');
            for c=1:3
                F = fftshift(fft2(double(I(:,:,c))));
                G = ifft2(ifftshift(F .* Htot));
                out(:,:,c) = real(G);
            end
            imgRes = cast(uint8(out),class(img));
        else
            F = fftshift(fft2(I));
            G = ifft2(ifftshift(F .* Htot));
            imgRes = cast(uint8(real(G)),class(img));
        end
        axes(hAxRes); imshow(imgRes); title('Notch Filter');
        setStatus('Notch done');
    end

    function cbWiener(~,~)
        if isempty(img), setStatus('Load image first'); return; end
        prompt = {'LEN (motion length, e.g.15)','THETA (angle, e.g.30)','Noise variance (e.g.0.001)'};
        def = {'20','30','0.001'};
        answ = inputdlg(prompt,'Motion & Wiener',1,def);
        if isempty(answ), setStatus('Cancelled'); return; end
        LEN = str2double(answ{1}); THETA = str2double(answ{2}); noise_var = str2double(answ{3});
        setStatus('Running motion blur and Wiener restoration...');
        Iorig = im2double(img);
        PSF = fspecial('motion',LEN,THETA);
        if ndims(Iorig)==3
            outRest = zeros(size(Iorig));
            [M,N,~] = size(Iorig);
            H = psf2otf(PSF,[M N]);
            for c=1:3
                fchan = Iorig(:,:,c);
                fblur = imfilter(fchan,PSF,'conv','circular');
                fnoisy = imnoise(fblur,'gaussian',0,noise_var);
                F = fft2(fnoisy);
                K = noise_var / var(fchan(:));
                G = (conj(H) ./ (abs(H).^2 + K)) .* F;
                frest = real(ifft2(G));
                outRest(:,:,c) = frest;
            end
            imgRes = im2uint8(outRest);
        else
            [M,N] = size(Iorig);
            H = psf2otf(PSF,[M N]);
            fblur = imfilter(Iorig,PSF,'conv','circular');
            fnoisy = imnoise(fblur,'gaussian',0,noise_var);
            F = fft2(fnoisy);
            K = noise_var / var(Iorig(:));
            G = (conj(H) ./ (abs(H).^2 + K)) .* F;
            frest = real(ifft2(G));
            imgRes = im2uint8(frest);
        end
        axes(hAxRes); imshow(imgRes); title('Wiener Restoration');
        setStatus('Wiener done');
    end

    function out = manual_conv_image(I,mask)
        if ndims(I)==3
            [M,N,~] = size(I);
            out = zeros(M,N,3);
            pad_row = floor(size(mask,1)/2); pad_col = floor(size(mask,2)/2);
            for c=1:3
                channel = double(I(:,:,c));
                channel_p = padarray(channel,[pad_row pad_col],0,'both');
                res = zeros(M,N);
                for x=1:M
                    for y=1:N
                        region = channel_p(x:x+2*pad_row,y:y+2*pad_col);
                        res(x,y) = sum(sum(region .* mask));
                    end
                end
                out(:,:,c) = res;
            end
            out = uint8(out);
        else
            channel = double(I);
            [M,N] = size(channel);
            pad_row = floor(size(mask,1)/2); pad_col = floor(size(mask,2)/2);
            channel_p = padarray(channel,[pad_row pad_col],0,'both');
            res = zeros(M,N);
            for x=1:M
                for y=1:N
                    region = channel_p(x:x+2*pad_row,y:y+2*pad_col);
                    res(x,y) = sum(sum(region .* mask));
                end
            end
            out = uint8(res);
        end
    end

    function out = builtin_conv_image(I,mask)
        if ndims(I)==3
            out = zeros(size(I),'double');
            for c=1:3
                out(:,:,c) = conv2(double(I(:,:,c)),double(mask),'same');
            end
            out = uint8(out);
        else
            out = conv2(double(I),double(mask),'same');
            out = uint8(out);
        end
    end

end
